package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods {
	
	public HomePage(ChromeDriver driver) {
		this.driver = driver;
		
	}
	
	public LoginPage clickLogoutButton() {
		driver.findElement(By.className("decorativeSubmit")).click();
		return new LoginPage(driver);
	}
	
	public MyHomePage clickCrmSfaLink() {
		System.out.println(driver);
		driver.findElement(By.linkText("CRM/SFA")).click();
		return new MyHomePage(driver);
	}
	
	public HomePage verifyHomePage() throws IOException {
		
		try {
			boolean displayed = driver.findElement(By.linkText("CRM/SFA")).isDisplayed();
			if(displayed) {
				reportStep("CRMSFA linked is displayed", "pass");
			}
						
		} catch (Exception e) {
			reportStep("CRMSFA linked is not displayed", "fail");
		}
		
		return this;
	}

}
