package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.HomePage;
import pages.LoginPage;

public class CreateLead extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setValues() {
		excelFileName="CreateLead";
		testName = "CreateLead";
		testDescription = "Create lead with mandatory informations";
		testAuthor = "Hari";
		testCategory = "Smoke";
	}
	
	@Test
	public void runCreateLead() throws InterruptedException, IOException {
		
		new LoginPage(driver)
		.enterUsername("DemoCSR")
		.enterPassword("crmsfa")
		.clickLoginButton()
		.clickCrmSfaLink()
		.clickLeadsLink()
		.clickCreateLeadLink()
		.enterCompanyName()
		.enterFirstName()
		.enterLastName()
		.createLeadButton()
		.verifyFirstName();

	}

}
